package com.br.CareerUp.exceptions;

public class IdNaoEncontradoException extends Exception{
    public IdNaoEncontradoException(String msg){super(msg);}
}
