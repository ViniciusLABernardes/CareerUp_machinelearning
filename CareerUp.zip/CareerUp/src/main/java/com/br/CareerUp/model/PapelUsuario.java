package com.br.CareerUp.model;

public enum PapelUsuario {
    USUARIO,
    GERENTE
}
