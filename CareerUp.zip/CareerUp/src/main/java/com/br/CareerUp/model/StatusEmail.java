package com.br.CareerUp.model;

public enum StatusEmail {
    PROCESSANDO,
    ENVIADO,
    ERRO;
}
