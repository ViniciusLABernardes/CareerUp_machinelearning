package com.br.CareerUp;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CareerUpApplicationTests {

	@Test
	void contextLoads() {
	}

}
